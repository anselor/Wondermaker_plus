"""Exact prebuilt screen payload verification. Never loads the candidate library."""
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import subprocess

BUNDLE = 'client-preload/openace-compat/screen1113'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def elf_contract(path):
    data=Path(path).read_bytes()
    if len(data)<64 or data[:6]!=b'\x7fELF\x02\x01':raise ValueError('bundle must be ELF64 little endian')
    kind,machine=struct.unpack_from('<HH',data,16)
    if kind!=3 or machine!=183:raise ValueError('bundle must be an AArch64 shared object')
    phoff=struct.unpack_from('<Q',data,32)[0];size,count=struct.unpack_from('<HH',data,54)
    if size<56 or count>128 or phoff+size*count>len(data):raise ValueError('invalid ELF program headers')
    loads=[];dynamic=None
    for n in range(count):
        tag,flags,offset,address,_,filesz,_,_=struct.unpack_from('<IIQQQQQQ',data,phoff+n*size)
        if offset+filesz>len(data):raise ValueError('invalid ELF segment')
        if tag==1:loads.append((address,offset,filesz))
        if tag==2:dynamic=(offset,filesz)
    if dynamic is None:raise ValueError('missing ELF dynamic table')
    tags={};needed=[]
    for pos in range(dynamic[0],dynamic[0]+dynamic[1]-15,16):
        tag,value=struct.unpack_from('<QQ',data,pos)
        if tag==0:break
        if tag==1:needed.append(value)
        else:tags[tag]=value
    strings=None
    for address,offset,length in loads:
        if address<=tags.get(5,-1)<address+length:
            start=offset+tags[5]-address;end=start+tags.get(10,0)
            if end>offset+length:raise ValueError('invalid ELF string table')
            strings=data[start:end]
    if strings is None:raise ValueError('missing ELF string table')
    names=[]
    for index in needed:
        end=strings.find(b'\0',index)
        if end<index:raise ValueError('invalid ELF dependency')
        names.append(strings[index:end].decode('ascii'))
    return dict(machine='AArch64',nodelete=bool(tags.get(0x6ffffffb,0)&8),needed=sorted(names))


def load_bundle(root):
    root=Path(root);directory=root/BUNDLE
    p=directory/'bundle.json'
    if not p.exists():return None  # Existing C-only package remains valid.
    value=json.loads(p.read_text())
    if type(value) is not dict or set(value)!={'version','scope','profile','artifact','source_manifest_sha256','source_archive_sha256','legacy_c_sha256'} or type(value['version']) is not int or value['version']!=1:
        raise ValueError('unsupported screen bundle descriptor')
    if value['scope'] not in ('packaging-control-only','reviewed-delivery'):
        raise ValueError('unknown screen bundle delivery scope')
    profile=value['profile'];artifact=value['artifact']
    if type(profile) is not dict or set(profile)!={'firmware','sha256','size'} or profile['firmware']!='1.1.13':raise ValueError('unsupported native profile')
    if type(artifact) is not dict or set(artifact)!={'file','sha256','size','machine','nodelete','needed'}:raise ValueError('invalid screen artifact fields')
    if not isinstance(artifact['file'],str) or not re.fullmatch(r'[A-Za-z0-9_.-]+',artifact['file']):raise ValueError('invalid bundle artifact path')
    if type(artifact['nodelete']) is not bool or type(artifact['needed']) is not list or any(type(name) is not str for name in artifact['needed']):raise ValueError('invalid ELF dependency metadata')
    for expected in (profile['sha256'],artifact['sha256'],value['source_manifest_sha256'],value['source_archive_sha256'],value['legacy_c_sha256']):
        if not isinstance(expected,str) or not re.fullmatch('[0-9a-f]{64}',expected):raise ValueError('invalid bundle digest')
    for length in (profile['size'],artifact['size']):
        if type(length) is not int or length<=0:raise ValueError('invalid bundle length')
    binary=directory/artifact['file']
    if binary.is_symlink() or not binary.is_file() or binary.stat().st_size!=artifact['size'] or digest(binary)!=artifact['sha256']:
        raise ValueError('screen artifact bytes do not match sealed descriptor')
    if digest(directory/'source-inputs.json')!=value['source_manifest_sha256']:raise ValueError('screen source manifest changed')
    if digest(root/'client-preload/openace-compat/wmp_openace_compat.c')!=value['legacy_c_sha256']:raise ValueError('screen bundle does not preserve this legacy compat source')
    actual=elf_contract(binary)
    if actual!={key:artifact[key] for key in actual} or not actual['nodelete']:raise ValueError('screen ELF dependency/NODELETE contract changed')
    return value


def native_source_files(root):
    """Repository-relative inputs sufficient for the pinned source rebuild."""
    root=Path(root);directory=root/BUNDLE;source=directory/'source'
    if not source.is_dir():raise ValueError('native source tree is missing')
    files=[p for p in source.rglob('*') if p.is_file()]
    toolchain=directory/'toolchain'
    if not toolchain.is_dir():raise ValueError('native toolchain provenance is missing')
    files += [p for p in toolchain.rglob('*') if p.is_file()]
    files += [root/'client-preload/openace-compat/wmp_openace_compat.c',
              root/'tools/preload_bundle.py']
    files += [directory/name for name in ('build-offline-arm.sh','repack-source.py',
              'toolchain.json','README.md','vendor-provenance.json')]
    files += [directory/'review-history'/name for name in ('source-review.json',
              'native121-inputs.json','inherited-source-review.md','target-dependency-preflight.json')]
    if not files or any(not p.is_file() or p.is_symlink() for p in files):
        raise ValueError('native rebuild input is missing or is a symlink')
    return tuple(sorted(str(p.relative_to(root)).replace('\\','/') for p in files))


def verify_source_binding(root,bundle=None):
    """Local package completeness; never a target motion or runtime permission."""
    import tarfile
    from pathlib import PurePosixPath
    root=Path(root);bundle=load_bundle(root) if bundle is None else bundle
    if bundle is None:return
    directory=root/BUNDLE
    inputs=json.loads((directory/'source-inputs.json').read_text())
    if type(inputs) is not dict or set(inputs)!=set(native_source_files(root)):
        raise ValueError('native source manifest does not cover the repository rebuild inputs')
    for name,want in inputs.items():
        path=PurePosixPath(name)
        if (not isinstance(name,str) or path.is_absolute() or '..' in path.parts
                or not isinstance(want,str) or not re.fullmatch('[0-9a-f]{64}',want)
                or digest(root/name)!=want):
            raise ValueError('native source input changed: '+str(name))
    archive=directory/'source.tar.gz'
    if (archive.is_symlink() or not archive.is_file()
            or digest(archive)!=bundle['source_archive_sha256']):
        raise ValueError('native source archive is missing or changed')
    seen=set()
    try:
        with tarfile.open(archive,'r:gz') as stream:
            for member in stream:
                if (not member.isfile() or member.name not in inputs or member.name in seen
                        or hashlib.sha256(stream.extractfile(member).read()).hexdigest()!=inputs[member.name]):
                    raise ValueError('native source archive member does not match its manifest')
                seen.add(member.name)
    except (tarfile.TarError,EOFError) as error:
        raise ValueError('native source archive is invalid: '+str(error)) from error
    if seen!=set(inputs):raise ValueError('native source archive omits rebuild inputs')


def exact_profile(bundle,client):
    p=Path(client)
    return p.is_file() and p.stat().st_size==bundle['profile']['size'] and digest(p)==bundle['profile']['sha256']


def validate_dependencies(bundle,code,output):
    if code or re.search(r'not found|undefined symbol|not a dynamic executable|statically linked',output,re.I):
        raise ValueError('screen dependencies/relocations unavailable: '+output[-4000:])
    for name in bundle['artifact']['needed']:
        if not re.search(re.escape(name)+r'\s+=>\s+/',output):raise ValueError('screen dependency unresolved: '+name)


def verify_dependencies(bundle,artifact):
    # glibc ldd trace/relocation mode, never dlopen or execute the candidate.
    result=subprocess.run(['ldd','-r',str(artifact)],capture_output=True,text=True,timeout=30,
                          env={k:v for k,v in os.environ.items() if k not in ('LD_PRELOAD','LD_LIBRARY_PATH')})
    validate_dependencies(bundle,result.returncode,result.stdout+'\n'+result.stderr)


def verify_staged(root,client):
    bundle=load_bundle(root)
    if bundle is None or not exact_profile(bundle,client):return False
    verify_dependencies(bundle,Path(root)/BUNDLE/bundle['artifact']['file'])
    return True



def select_delivery(root,client):
    bundle=load_bundle(root)
    if bundle is None or not exact_profile(bundle,client):return False
    if bundle['scope']!='reviewed-delivery':
        raise ValueError('screen bundle is packaging-control-only; final reviewed UI artifact required before installation')
    verify_dependencies(bundle,Path(root)/BUNDLE/bundle['artifact']['file'])
    return True


def preflight_script(root,client):
    """Disposable remote port; payload is exact local verified package bytes."""
    root=Path(root);bundle=load_bundle(root)
    if bundle is None:return ''
    source_error=''
    try:verify_source_binding(root,bundle)
    except (ValueError,OSError,KeyError,TypeError) as error:source_error=str(error)
    files={}
    for relative in (BUNDLE+'/bundle.json',BUNDLE+'/source-inputs.json',BUNDLE+'/'+bundle['artifact']['file'],
                     'client-preload/openace-compat/wmp_openace_compat.c'):
        files[relative]=base64.b64encode((root/relative).read_bytes()).decode('ascii')
    return Path(__file__).read_text()+'''\nimport tempfile\nwith tempfile.TemporaryDirectory(prefix='wmp-screen-check-') as temporary:\n for relative, encoded in %r.items():\n  target=Path(temporary)/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(base64.b64decode(encoded))\n bundle=load_bundle(temporary)\n if exact_profile(bundle,%r) and %r:raise ValueError('native source delivery unavailable: '+%r)\n enabled=select_delivery(temporary,%r)\n print('screen bundle exact1113 dependency check passed' if enabled else 'screen unavailable on this profile; existing C fixes retained')\n'''%(files,client,source_error,source_error,client)


def restore_publication(stage):
    """Restore exact owned destinations; never adopt an incomplete candidate."""
    import shutil
    stage=Path(stage);journal=stage/'publication.json'
    if not journal.exists():return
    rows=json.loads(journal.read_text())
    for row in reversed(rows):
        target=Path(row['target'])
        if row['backup'] is None:
            if target.exists():target.unlink()
        else:
            temp=target.with_name(target.name+'.wmp-restore')
            shutil.copy2(stage/row['backup'],temp);os.replace(temp,target)


def publish_stage(stage,libdir,dropin):
    import shutil
    stage=Path(stage);libdir=Path(libdir);dropin=Path(dropin)
    outputs=json.loads((stage/'outputs.json').read_text())
    if not outputs or any(not re.fullmatch(r'libwmp_[A-Za-z0-9_-]+\.so',name) for name in outputs):raise ValueError('invalid staged library list')
    for name,row in outputs.items():
        if (not isinstance(row,dict) or set(row)!={'file','sha256'} or not re.fullmatch(r'[A-Za-z0-9_.-]+',row['file'])
                or not re.fullmatch('[0-9a-f]{64}',row['sha256']) or digest(stage/row['file'])!=row['sha256']):
            raise ValueError('staged library bytes changed before publication: '+name)
    duplicates=[p.name for p in libdir.glob('libwmp_openace*.so') if p.name!='libwmp_openace-compat.so']
    if duplicates:raise ValueError('ambiguous duplicate compat/screen library: '+', '.join(duplicates))
    libdir.mkdir(parents=True,exist_ok=True);dropin.parent.mkdir(parents=True,exist_ok=True)
    targets=[(libdir/name,stage/row['file']) for name,row in sorted(outputs.items())]
    libs=sorted({str(p) for p in libdir.glob('libwmp_*.so')}|{str(t) for t,_ in targets})
    prospective=stage/'prospective-dropin';prospective.write_text('[Service]\nEnvironment="LD_PRELOAD=%s"\n'%' '.join(libs))
    targets.append((dropin,prospective));rows=[]
    for index,(target,_) in enumerate(targets):
        if target.is_symlink() or target.exists() and not target.is_file():raise ValueError('refusing non-regular preload destination: '+str(target))
        backup=None
        if target.exists():backup='previous-%d'%index;shutil.copy2(target,stage/backup)
        rows.append(dict(target=str(target),backup=backup))
    (stage/'publication.json').write_text(json.dumps(rows))
    try:
        for target,source in targets:
            temp=target.with_name(target.name+'.wmp-new');shutil.copy2(source,temp);os.replace(temp,target)
    except Exception:
        restore_publication(stage)
        raise
    return libs
