#!/bin/bash
# Install the Wondermaker+ screen bridge. Runs ON the printer, as root.
#
# Creates the screen bridge files and two services, adds the Fluidd nginx
# include and Moonraker camera entry, and selects the print camera for timelapse.
# Uninstall removes the bridge; it does not restore the old timelapse setting.
set -euo pipefail

PREFIX=/opt/wondermaker_plus
NGINX_SITE=/etc/nginx/sites-available/fluidd
UNIT=/etc/systemd/system/wmp-screen.service
TL_UNIT=/etc/systemd/system/wmp-timelapse-camera.service
MARKER="# wondermaker_plus"
INCLUDE_LINE="    include ${PREFIX}/nginx-screen.conf; ${MARKER}"
MOONRAKER=http://127.0.0.1:7125
WEBCAM_NAME="Touchscreen"
TL_CAMERA="camera"        # real webcam name the timelapse must use
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

say() { echo "==> $*"; }
die() { echo "!! $*" >&2; exit 1; }

[ "$(id -u)" = 0 ] || die "Run this printer-side script as root."
[ -f "$SRC/device/wmp_screen.py" ] || die "Screen bridge files are missing under $SRC/device."

# --- 1. payload ------------------------------------------------------------
say "copying screen bridge files to $PREFIX"
mkdir -p "$PREFIX/backup"
cp -a "$SRC/device/wmp_screen.py" "$SRC/device/nginx-screen.conf" \
      "$SRC/device/timelapse-camera-fix.sh" "$PREFIX/"
chmod +x "$PREFIX/timelapse-camera-fix.sh"
rm -rf "$PREFIX/www"
cp -a "$SRC/device/www" "$PREFIX/www"
echo "$(cat /home/t13dp/iso_version.txt 2>/dev/null | head -1)" > "$PREFIX/installed-against.txt"
date -u +"installed %Y-%m-%dT%H:%M:%SZ" >> "$PREFIX/installed-against.txt"

# --- 2. nginx --------------------------------------------------------------
if grep -qF "$MARKER" "$NGINX_SITE"; then
    say "screen include already exists in nginx"
else
    say "backing up $NGINX_SITE"
    cp -a "$NGINX_SITE" "$PREFIX/backup/fluidd.orig"
    md5sum "$NGINX_SITE" > "$PREFIX/backup/fluidd.orig.md5"

    say "adding the screen page to the Fluidd web-server configuration"
    python3 - "$NGINX_SITE" "$INCLUDE_LINE" <<'PY'
import sys
path, line = sys.argv[1], sys.argv[2]
src = open(path).read()
idx = src.rstrip().rfind("}")          # final brace closes the server block
if idx == -1:
    sys.exit("could not find closing brace in %s" % path)
open(path, "w").write(src[:idx] + line + "\n" + src[idx:])
PY

    if ! nginx -t 2>/dev/null; then
        say "nginx rejected the config; rolling back"
        cp -a "$PREFIX/backup/fluidd.orig" "$NGINX_SITE"
        nginx -t || true
        die "nginx config test failed, original restored"
    fi
fi

# --- 3. service ------------------------------------------------------------
say "installing the screen bridge service"
cp -a "$SRC/device/wmp-screen.service" "$UNIT"
systemctl daemon-reload
systemctl enable wmp-screen.service >/dev/null 2>&1 || true
systemctl restart wmp-screen.service

say "reloading nginx"
systemctl reload nginx || systemctl restart nginx

# --- 4. moonraker webcam ---------------------------------------------------
say "registering '$WEBCAM_NAME' webcam with Moonraker"
for _ in $(seq 1 10); do
    curl -sf -m 3 "$MOONRAKER/server/info" >/dev/null && break
    sleep 1
done
curl -sf -m 5 -X POST "$MOONRAKER/server/webcams/item" \
    -H "Content-Type: application/json" \
    -d "{\"name\": \"$WEBCAM_NAME\",
         \"service\": \"iframe\",
         \"location\": \"printer\",
         \"icon\": \"mdiTelevision\",
         \"enabled\": true,
         \"aspect_ratio\": \"5:3\",
         \"target_fps\": 10,
         \"target_fps_idle\": 2,
         \"stream_url\": \"/wmp-screen/\",
         \"snapshot_url\": \"/wmp-screen/snapshot.jpg\",
         \"flip_horizontal\": false,
         \"flip_vertical\": false,
         \"rotation\": 0}" >/dev/null \
    || echo "!! Could not register Touchscreen with Moonraker. Add an iframe camera in Fluidd using /wmp-screen/."

# --- 5. timelapse camera fixer --------------------------------------------
# Registering the Touchscreen webcam above is exactly what makes the vendor
# timelapse fall back to the LCD mirror, so fix it here: a oneshot unit that
# forces the timelapse camera back to the real webcam on every boot, plus
# once now.
say "setting timelapse recording to the print camera"
cp -a "$SRC/device/wmp-timelapse-camera.service" "$TL_UNIT"
systemctl daemon-reload
systemctl enable wmp-timelapse-camera.service >/dev/null 2>&1 || true
WMP_MOONRAKER="$MOONRAKER" WMP_TIMELAPSE_CAMERA="$TL_CAMERA" \
    "$PREFIX/timelapse-camera-fix.sh" || true

# --- report ----------------------------------------------------------------
sleep 2
say "service status:"
systemctl is-active wmp-screen.service || true
curl -sf -m 5 -o /dev/null -w "    local  /snapshot.jpg -> HTTP %{http_code}\n" \
    http://127.0.0.1:8975/snapshot.jpg || echo "    local snapshot FAILED"
curl -sf -m 5 -o /dev/null -w "    nginx  /wmp-screen/  -> HTTP %{http_code}\n" \
    http://127.0.0.1/wmp-screen/ || echo "    nginx proxy FAILED"
say "installation steps finished; review the checks above, then open Fluidd and look for the '$WEBCAM_NAME' camera"
